# General information
This repository contains the OpenAPI template definition for the SOVD API. This is part of the ASAM standard release.

As this is only a template it is not meant to be use it as input for a code generator. Instead a server-specific capability description needs to be created that defines the specific resources a server supports. That can then be used to generate API client and server code.

For more information about the SOVD API, supported resources and the capability description see the ASAM SOVD standard.

An example capability description is available at: https://code.asam.net/diagnostics/sovd/capability-description-example

# Tools

## Git version control
Git is used as the versioning control system for the OpenAPI specification.

There a wide range of clients available for Windows. For example:
* Basic commandline client (https://git-scm.com/download/win)
* Tortoise GIT Windows Explorer integration (https://tortoisegit.org/)
* Sourcetree rich GUI client (https://www.sourcetreeapp.com/)

More information about how to use Git can be found in the Git book https://git-scm.com/book/

There also also many tutorials and resources for a quick start available online.

## Configuring Git

1. (important) Make sure your commits match your name and email. In a PowerShell or terminal window, type:

```git
   git config --global user.name "FIRST_NAME LAST_NAME"
   git config --global user.email "MY_NAME@example.com"
```

2. (optional) Make a `git pull` not to create any annoying merge commits and not to abort in case of uncommitted local changes. In a PowerShell or terminal window, type:

```git
   git config --global branch.autoSetupRebase remote
   git config --global rebase.autoStash true
```
The described configuration steps are one time actions. They create a global git configuration that applies to all repositories that you have already set up or will set up. It also applies regardless of whether you issue git commands in a terminal window or within VSCode.

## Install Visual Studio Code and extensions

It is recommended to use Visual Studio Code (aka VSCode) to edit and process the OpenAPI files in this repository. VSCode is an all-in-one open-source text editor with built-in GIT support and a rich library of optional extensions that ease many tasks (code completion, syntax checking, building, launching, debugging and testing).

VSCode can be downloaded and installed from https://code.visualstudio.com/download. See the [VSCode Guide](../guides/VSCode-Guide) for a short introduction to the basics of VSCode. The full documentation can be found at https://code.visualstudio.com/docs.

The following extensions are recommended because the make life a lot easier when working on the OpenAPI files.
* https://marketplace.visualstudio.com/items?itemName=redhat.vscode-yaml
* https://marketplace.visualstudio.com/items?itemName=Redocly.openapi-vs-code
* https://marketplace.visualstudio.com/items?itemName=stoplight.spectral

To install an extensions just click on the "Install" button on the website.

If you want to do it manually:
* In the VSCode menu bar, go to `View` → `Extensions`
* Search for your extension & install it

## Spectral linter

Instead of or in addition to the VisualStudio Plug-In you can download the Spectral linter commandline tool: https://github.com/stoplightio/spectral/releases

In order to run the linter on the SOVD OpenAPI template execute the following commands:

```
   spectral lint --fail-severity=warn sovd-api.yaml
   spectral lint --fail-severity=warn authentication-api.yaml
```


# Contributing changes to the SOVD OpenAPI specification
After you cloned the repository before changing anything on the code, create a new branch. The name should clearly state what this branch is for.
```git
   git checkout -b UC02_Trigger_Based_Access
```

You can now edit commit and push your changes. Recommendation: Make many commits, so you can go back in history in smaller steps if something goes wrong.

When your contribution is ready, open GitLab and create a Merge request. https://code.asam.net/sovd/openapi-specification/-/merge_requests
* Source Branch is your newly created branch
* Target Branch is "master"

Create the Merge request with some accompanying description and inform the group so everyone can review.

You can also create the merge request before you actually finish your work, please start it in draft status then.

When the merge request is ready for review make sure the draft status is removed and add the "isState: Implemented" tag

**Before you make your merge request ready for review, please ensure the build is green**.

After reviews are done and comments are addressed, one of the maintainers of the repository can merge the branch into master.
