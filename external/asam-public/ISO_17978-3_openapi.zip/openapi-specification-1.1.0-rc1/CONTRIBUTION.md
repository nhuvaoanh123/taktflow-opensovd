# Coding Guidelines

## General repository structure

### File: sovd-api.yml
This is the root file of the OpenAPI specification. It lists all resources in the *paths* section but must only contain links to the actual resource definition inside subfolders.

### File: authentication-api.yml
This is the root file of the OpenAPI specification for the authentication API.

### Folder: commons
Contains definitions that are relevant for all or multiple resources

### Resource folders
There is one folder per resource - usually referring to chapters in the specification. All definitions that are related to that specific resource go into that folder.

## General guidelines

### Descriptions
There shall be descriptions in the OpenAPI specification at least when there are descriptions in the specification document as well. Descriptions in the OpenAPI specification shall be as close to the description in the specification document as possible. Ideally it's a copy but this this is not always the case.

### Examples
Examples in the specification document shall also be available in the OpenAPI specification.

## Structure of resource definitions

Each resource folder contains a file that has the same name as the resource/folder. This is the entry-point containing all paths. The root file references paths within these files.

For example, the definition of resource 'operations' lives in a folder called 'operations' and all paths of that resource are defined in a file called 'operations/operations.yaml'. The sovd-api.yaml contains references to all paths within that file.

* Each path in that entry-point file shall contain a tag with the name of the resource. This is for easier overview when using a graphical application.
* Each path shall list the parameters and responses valid for that particular path but not their definitions. Instead it should only only contain references to parameter and response definitions.
* Definition of Parameters shall always be in a file called parameters.yaml.
* Definition of Responses shall always be in a file called responses.yaml.
* The files for parameter and response definitions can either be located in the same folder (for resource specific parameters/responses) or in the commons folder (for parameters/responses shared between resources)
* Types that are not specific to parameters or responses shall be defined in a separate file called types.yaml
* Always use single quotes around references. e.g. $ref: 'types.yaml#/components/schemas/AnyValue'

## Naming
In general all names shall be exactly as in the specification document. For OpenAPI specific identifiers of e.g. parameter or response definitions CamelCase with first letter capital shall be used.


